# IBM Notas en local

1. Usa PHP 8.3 o 8.4 y MySQL 8 o MariaDB 10.6 o posterior. Revisa las extensiones en [la guía](hostinger/README.md). Las dependencias de Composer ya están incluidas en `vendor/`.
2. Crea una base vacía e importa `hostinger/database/schema.sql` con phpMyAdmin o el cliente de MySQL.
3. En `hostinger/`, copia `config.example.php` a `config.php`. Pon los datos de tu base y cambia `secure_cookies` a `false` para probar con HTTP local.
4. Desde `hostinger/`, ejecuta `php bin/create-admin.php admin "Administración IBM"`. Escribe una contraseña de prueba en la terminal y pulsa Enter. Úsala para entrar y cámbiala cuando el sistema lo solicite. En Bash puedes seguir el ejemplo de la guía para introducirla sin mostrarla.
5. Ejecuta `php -S 127.0.0.1:8080 -t public_html` y abre `http://127.0.0.1:8080/`.

Para cargar el catálogo de materias, ejecuta `php bin/import-catalog.php ../catalogs/ceicom-2026.json --apply` desde `hostinger/`. El esquema inicia sin estudiantes ni cuentas.

Consulta [la guía](hostinger/README.md) para desplegar en Hostinger, migrar desde PostgreSQL o restaurar un respaldo. El [README de referencia](REFERENCIA.md) incluye el formato JSON para cargar grupos históricos.
