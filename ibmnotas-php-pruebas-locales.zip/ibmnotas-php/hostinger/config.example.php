<?php
return [
    'dsn' => 'mysql:host=localhost;dbname=BASE;charset=utf8mb4',
    'user' => 'USUARIO',
    'password' => '',
    'secure_cookies' => true,
    'backup_directory' => __DIR__ . '/storage/backups',
];
