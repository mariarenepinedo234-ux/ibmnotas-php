# IBM Notas para Hostinger

Aplicación PHP 8.3 con MySQL y Bootstrap 5 para el Instituto Técnico Británico Mercantil. Usa el escudo de IBM y la paleta institucional. El directorio `public_html/` contiene los archivos públicos. El resto contiene PHP privado, dependencias y herramientas de instalación.

## Instalación en hPanel

1. Selecciona PHP 8.3 o 8.4. Habilita `pdo_mysql`, `sodium`, `mbstring`, `gd`, `zip`, `fileinfo` y las extensiones XML requeridas por Composer. La compilación de PHP debe ofrecer Argon2id para las contraseñas nuevas. Verifica `composer check-platform-reqs --no-dev`. Para planillas grandes aumenta `memory_limit` y configura `max_input_vars` con al menos cuatro campos por estudiante más los campos del formulario. Para planes PDF de hasta 20 MB, configura el límite de subida, `post_max_size` y `max_allowed_packet` de acuerdo con los límites de tu plan.
2. Crea una base MySQL/MariaDB vacía y su usuario en hPanel. Importa `database/schema.sql` mediante phpMyAdmin. El esquema requiere InnoDB, MySQL 8 o MariaDB 10.6 o posterior y `utf8mb4`. Usa una base dedicada.
3. En una máquina con PHP y Composer, ejecuta `composer install --no-dev --prefer-dist --optimize-autoloader` desde este directorio. Puedes hacerlo por SSH si tu plan lo permite o subir el directorio `vendor/` generado localmente.
4. Coloca `app/`, `bin/`, `vendor/` y el archivo privado `config.php` junto al directorio público del dominio. Copia el **contenido** de `public_html/` del proyecto en el directorio público. Mantén la relación de directorios de este ejemplo y conserva los permisos mínimos que permitan a PHP leer la configuración y escribir en `storage/`.

   ```text
   domains/tu-dominio/
     app/
     bin/
     vendor/
     config.php
     storage/
     public_html/
       index.php
       assets/
   ```

5. Copia `config.example.php` a `config.php` y configura el DSN, el usuario y la contraseña de la base de hPanel. Mantén `secure_cookies` en `true` y fuerza HTTPS en hPanel. Configura `display_errors=Off` y el registro de errores privado. Mantén los respaldos fuera del directorio público.
6. Si empiezas con una base nueva, crea el primer administrador por SSH. El comando lee la clave por entrada estándar. En Bash puedes introducirla sin mostrarla ni guardarla en el historial.

   ```bash
   read -r -s -p 'Clave inicial: ' admin_password
   printf '\n'
   printf '%s\n' "$admin_password" | php bin/create-admin.php admin 'Administración IBM'
   unset admin_password
   ```

   Si vas a migrar una instalación existente, ejecuta primero el migrador. Este copia las cuentas existentes y requiere un destino vacío. Si tu plan carece de SSH, instala, migra o crea el administrador en una máquina local, exporta **la base MySQL resultante** con `mysqldump` o phpMyAdmin e impórtala en hPanel. No ejecutes el esquema nuevamente si ese volcado ya contiene las tablas.
7. Abre el dominio por HTTPS. Comprueba el acceso y prueba con una cuenta autorizada una inscripción, una planilla y la generación de un respaldo. Usa datos ficticios para las pruebas de instalación.

## Migración desde PostgreSQL

La fuente debe tener aplicadas las migraciones 001–012 del repositorio original (referencia `dd3279860df93caefb1cf2c6590bba46ea7a22d4`). Trabaja en una máquina que alcance ambas bases y que tenga `pdo_pgsql` y `pdo_mysql`. Puedes migrar desde una copia restaurada de PostgreSQL y luego subir el volcado de MySQL. Conserva las copias y archivos de configuración en almacenamiento privado.

1. Haz un `pg_dump --format=custom` del origen. Ensaya la migración en una base MySQL desechable. Para el traslado definitivo, detén las escrituras en la aplicación original antes del respaldo y mantén esa pausa hasta validar el destino.
2. Importa `database/schema.sql` en un destino vacío. Apunta el archivo privado `config.php` al destino. Crea otro archivo PHP **fuera del directorio público** para la conexión de origen. Usa una cuenta con permiso de lectura y TLS verificado si la conexión es remota.

   ```php
   <?php
   return [
       'dsn' => 'pgsql:host=127.0.0.1;port=5432;dbname=ceicom',
       'user' => 'usuario_lectura',
       'password' => 'valor_configurado_fuera_del_codigo',
   ];
   ```

3. Ejecuta `php bin/migrate-postgres.php /ruta/privada/postgres.php` desde este directorio. El script lee una instantánea en modo de solo lectura. Conserva IDs, relaciones, nombres de carrera por gestión, notas, intentos, auditoría, archivos de planes y hashes. Comprueba los conteos y revierte los datos de destino si ocurre un error. Las sesiones y las vistas previas temporales de importación se regeneran.
4. Compara los conteos de salida con el origen. Revisa una carrera renombrada en dos gestiones, grupos con notas, inscripciones retomas y algún PDF de plan de estudios. Verifica el acceso con cuentas autorizadas antes de cambiar el dominio. Las claves scrypt heredadas se convierten a Argon2id tras un inicio válido. Los usuarios con cambio pendiente conservan ese requisito.
5. Conserva el respaldo de PostgreSQL y el acceso al sistema original para poder volver a la versión anterior. Si ya hubo escrituras en MySQL, coordina su reconciliación antes de conmutar.

## Respaldos

El administrador puede crear y descargar un respaldo JSONL consistente desde **Respaldos**. Contiene datos personales y hashes de contraseñas. Descárgalo a almacenamiento privado con control de acceso y programa además los respaldos de la base desde el proveedor. Para ensayar una recuperación, crea una base nueva, importa el esquema y, apuntando `config.php` a esa base, ejecuta `php bin/restore.php /ruta/privada/respaldo.jsonl`. La herramienta verifica el formato, la suma SHA-256, los conteos y las restricciones dentro de una transacción. Para restaurar en producción, valida primero la copia restaurada y cambia la conexión del sitio durante una ventana de mantenimiento.

## Catálogo inicial

Puedes cargar un Excel institucional desde **Catálogo → Importar catálogo Excel**. La vista previa solo usa la hoja `BASE DE DATOS`. Revisa las materias y el directorio docente antes de aplicar el archivo. Un docente importado por nombre requiere CI confirmado para habilitar su cuenta.

El catálogo revisado del repositorio se puede cargar por CLI. Conserva el historial de nombres de carrera ya registrado.

```bash
php bin/import-catalog.php ../catalogs/ceicom-2026.json
php bin/import-catalog.php ../catalogs/ceicom-2026.json --apply
```

## Desarrollo local

Con PHP 8.3 y MySQL configurados, ejecuta `php -S 127.0.0.1:8080 -t public_html` desde este directorio. Para HTTP local fija `secure_cookies` en `false` en la configuración privada de desarrollo. En Hostinger usa HTTPS y `secure_cookies` en `true`.

## Carga histórica de grupos

La herramienta `php bin/import-groups.php /ruta/privada/grupos.json` valida el formato JSON descrito en el README de referencia. Añade `--apply` para aplicar la carga. Usa un archivo privado autorizado. Si identifica inequívocamente a un estudiante existente, conserva sus datos. Las personas nuevas quedan sin CI ni acceso hasta que administración confirme su identidad.
