@echo off
setlocal
set "PHP_EXE=%~dp0..\..\php\php.exe"
if not exist "%PHP_EXE%" (
    echo No se encontro php.exe. Extrae ibmnotas dentro de htdocs de XAMPP.
    pause
    exit /b 1
)
echo Con MySQL encendido y el esquema importado, escribe una clave de prueba de al menos 8 caracteres y pulsa Enter.
"%PHP_EXE%" "%~dp0private\bin\create-admin.php" admin "Administracion IBM"
set "RESULT=%errorlevel%"
pause
exit /b %RESULT%
